#!/bin/bash
# ==========================================================================
# LABYRINTH-O — run.sh
# Organelle patch launcher
# ==========================================================================

PATCH_DIR="$(dirname "$(readlink -f "$0")")"
BINARY="$PATCH_DIR/labyrinth"
LOG="$PATCH_DIR/crash.log"

mkdir -p /usbdrive/Patches/LabyrinthO

echo "=== LABYRINTH-O ===" | tee -a "$LOG"
echo "$(date)"             | tee -a "$LOG"
echo "PATCH_DIR: $PATCH_DIR" | tee -a "$LOG"

oscsend localhost 4001 /oled/line/1 s "LABYRINTH-O"
oscsend localhost 4001 /oled/line/2 s "Starting..."

# Check binary exists
if [ ! -f "$BINARY" ]; then
    echo "ERROR: binary not found at $BINARY" | tee -a "$LOG"
    oscsend localhost 4001 /oled/line/2 s "Binary missing!"
    exit 1
fi

# Ensure execute permission (FAT32 strips +x)
chmod +x "$BINARY"

# Kill JACK so we can use ALSA directly
echo "Stopping JACK..." | tee -a "$LOG"
killall jackd 2>/dev/null || true
oscsend localhost 4001 /oled/line/2 s "JACK killed..."
sleep 3

# Kill ttymidi so we can own the DIN MIDI serial port directly.
# ttymidi silently drops MIDI realtime messages (clock/start/stop) — we bypass it.
echo "Stopping ttymidi..." | tee -a "$LOG"
# Try systemd first (handles watchdog/service restarts)
systemctl stop ttymidi 2>/dev/null || true
systemctl disable ttymidi 2>/dev/null || true
# Also try init.d style
/etc/init.d/ttymidi stop 2>/dev/null || true
# Kill any remaining process (pkill -f matches full command line)
pkill -9 -f ttymidi 2>/dev/null || true
killall -9 ttymidi 2>/dev/null || true
# Force-release the serial port from any process holding it open
# (covers the case where ttymidi is restarted by a watchdog between kills)
for port in /dev/ttyAMA0 /dev/ttyAMA1 /dev/ttymxc1 /dev/ttymxc2; do
    if [ -e "$port" ]; then
        fuser -k "$port" 2>/dev/null || true
    fi
done
# Wait until the process is truly gone (up to 3 seconds)
for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    if ! pgrep -x ttymidi > /dev/null 2>&1; then break; fi
    sleep 0.2
done
if pgrep -x ttymidi > /dev/null 2>&1; then
    echo "WARNING: ttymidi still running after kill — serial port may be busy" | tee -a "$LOG"
else
    echo "ttymidi stopped OK" | tee -a "$LOG"
fi

# Kill any leftover instance
killall labyrinth 2>/dev/null || true

# ldd check
echo "ldd check:" | tee -a "$LOG"
ldd "$BINARY" 2>&1 | tee -a "$LOG" || true

oscsend localhost 4001 /oled/line/2 s "Launching..."

# Launch — synchronous, same as original working build
echo "Starting labyrinth..." | tee -a "$LOG"
"$BINARY" >> "$LOG" 2>&1

EXIT_CODE=$?
echo "labyrinth exited with code $EXIT_CODE" | tee -a "$LOG"

if [ "$EXIT_CODE" -ne 0 ]; then
    oscsend localhost 4001 /oled/line/2 s "Crashed: $EXIT_CODE"
    oscsend localhost 4001 /oled/line/3 s "See crash.log"
    sleep 20
fi

exit "$EXIT_CODE"
